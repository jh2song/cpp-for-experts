#pragma once

namespace mycode {
	void foo();
}
