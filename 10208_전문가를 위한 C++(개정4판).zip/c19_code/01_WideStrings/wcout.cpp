#include <iostream>

using namespace std;

int main()
{
	wcout << L"I am a wide-character string literal." << endl;

	return 0;
}
