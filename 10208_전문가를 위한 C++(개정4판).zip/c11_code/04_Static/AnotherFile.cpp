#include <iostream>

void f();
//static void f();

void f()
{
	std::cout << "f\n";
}
