extern int x;
int x = 3;

//extern int x = 3;
