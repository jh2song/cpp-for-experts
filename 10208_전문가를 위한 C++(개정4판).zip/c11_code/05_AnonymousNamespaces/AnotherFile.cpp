#include <iostream>

namespace {
	void f();

	void f()
	{
		std::cout << "f\n";
	}
}
