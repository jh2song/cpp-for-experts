#include "LoggerAdaptor.h"

int main() 
{
	NewLoggerAdaptor logger;
	logger.log("Testing the logger.");

	return 0;
} 
