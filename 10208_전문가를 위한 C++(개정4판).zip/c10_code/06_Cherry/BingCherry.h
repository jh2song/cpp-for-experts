#pragma once

#include "Cherry.h"

class BingCherry : public Cherry
{
public:
	virtual void printType() override;

	virtual void polish();
};
