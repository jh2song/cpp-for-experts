#include "BingCherry.h"
#include <iostream>

void BingCherry::printType()
{
	std::cout << "I am a Bing Cherry" << std::endl;
}

void BingCherry::polish()
{
	std::cout << "I am getting polished" << std::endl;
}
