#include "CherryTree.h"

Cherry* CherryTree::pick()
{
	return new Cherry();
}
