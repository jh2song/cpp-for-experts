#include "Cherry.h"
#include <iostream>

void Cherry::printType()
{
	std::cout << "I am a Cherry" << std::endl;
}
